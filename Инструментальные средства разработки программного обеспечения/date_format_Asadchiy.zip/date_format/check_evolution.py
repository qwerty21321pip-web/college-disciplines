from pathlib import Path
import profile_pb2
p=profile_pb2.Profile()
p.ParseFromString(Path('received/message_protobuf.pb').read_bytes())
print('Старый файл прочитан новой схемой')
print('Имя:',p.name)
print('Email (новое поле):',repr(p.email))
assert p.name=='Анна Смирнова' and p.email==''
print('Проверка обратной совместимости: OK')
