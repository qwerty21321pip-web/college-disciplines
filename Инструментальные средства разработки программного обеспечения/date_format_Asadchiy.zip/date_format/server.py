import socket
from pathlib import Path
from formats import decode
HOST, PORT = '127.0.0.1', 9999
MAP={b'J':('json','json'),b'M':('msgpack','msgpack'),b'C':('cbor','cbor'),b'P':('protobuf','pb')}
def recv_exact(conn, n):
    data=bytearray()
    while len(data)<n:
        chunk=conn.recv(n-len(data))
        if not chunk:raise ConnectionError('Соединение закрыто до конца сообщения')
        data.extend(chunk)
    return bytes(data)
if __name__=='__main__':
    with socket.socket(socket.AF_INET,socket.SOCK_STREAM) as server:
        server.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
        server.bind((HOST,PORT));server.listen(1)
        print(f'Сервер слушает {HOST}:{PORT}...',flush=True)
        conn,addr=server.accept()
        with conn:
            conn.settimeout(5)
            fmt,ext=MAP[recv_exact(conn,1)]
            length=int.from_bytes(recv_exact(conn,4),'big')
            if length>1024*1024:raise ValueError('Слишком большое сообщение')
            payload=recv_exact(conn,length)
            print(f'=== Получено {len(payload)} байт, формат: {fmt} ===')
            print('HEX:',payload.hex())
            try:print('TEXT:',payload.decode('utf-8'))
            except UnicodeDecodeError:print('TEXT: <не текст, бинарные данные>')
            print('DATA:',decode(fmt,payload))
            Path('received').mkdir(exist_ok=True)
            path=Path('received')/f'message_{fmt}.{ext}';path.write_bytes(payload)
            print('[СОХРАНЕНО]',path,f'({len(payload)} байт)')
