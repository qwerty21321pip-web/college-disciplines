import json
import xml.etree.ElementTree as ET
import yaml, msgpack, cbor2, profile_pb2
from data import PROFILE

def dict_to_xml(tag, data):
    root = ET.Element(tag)
    for key, value in data.items():
        if isinstance(value, dict):
            root.append(dict_to_xml(key, value))
        elif isinstance(value, list):
            group = ET.SubElement(root, key)
            for item in value:
                ET.SubElement(group, 'item').text = str(item)
        else:
            ET.SubElement(root, key).text = str(value)
    return root

def to_proto(data):
    p = profile_pb2.Profile()
    p.id = data['id']; p.name = data['name']; p.age = data['age']
    p.is_student = data['is_student']; p.courses.extend(data['courses'])
    p.address.city = data['address']['city']; p.address.zip = data['address']['zip']
    return p

def encode(fmt, data=PROFILE, pretty=False):
    if fmt == 'json':
        return json.dumps(data, ensure_ascii=False, indent=2 if pretty else None).encode('utf-8')
    if fmt == 'xml': return ET.tostring(dict_to_xml('profile', data), encoding='utf-8')
    if fmt == 'yaml':
        return yaml.dump(data, allow_unicode=True, sort_keys=False, default_flow_style=False).encode('utf-8')
    if fmt == 'msgpack': return msgpack.packb(data, use_bin_type=True)
    if fmt == 'cbor': return cbor2.dumps(data)
    if fmt == 'protobuf': return to_proto(data).SerializeToString()
    raise ValueError(fmt)

def decode(fmt, payload):
    if fmt == 'json': return json.loads(payload.decode('utf-8'))
    if fmt == 'yaml': return yaml.safe_load(payload.decode('utf-8'))
    if fmt == 'msgpack': return msgpack.unpackb(payload, raw=False)
    if fmt == 'cbor': return cbor2.loads(payload)
    if fmt == 'protobuf':
        p = profile_pb2.Profile(); p.ParseFromString(payload)
        return dict(id=p.id, name=p.name, age=p.age, is_student=p.is_student,
                    courses=list(p.courses), address=dict(city=p.address.city, zip=p.address.zip))
    if fmt == 'xml':
        p = ET.fromstring(payload)
        return dict(id=int(p.findtext('id')), name=p.findtext('name'), age=int(p.findtext('age')),
                    is_student=p.findtext('is_student') == 'True',
                    courses=[c.text for c in p.find('courses')],
                    address=dict(city=p.findtext('address/city'), zip=p.findtext('address/zip')))
    raise ValueError(fmt)

def show(fmt):
    payload=encode(fmt, pretty=(fmt=='json'))
    print('===', fmt.upper(), '===')
    print(payload.decode('utf-8') if fmt in ('json','xml','yaml') else 'HEX: '+payload.hex())
    print('Размер:', len(payload), 'байт')
    restored=decode(fmt,payload);assert restored == PROFILE
    print('Десериализация успешна:', restored['name'])
