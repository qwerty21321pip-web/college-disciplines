from formats import show
if __name__ == "__main__":
    show("cbor")
