import socket,sys
from formats import encode
HOST,PORT='127.0.0.1',9999
FMT=sys.argv[1] if len(sys.argv)>1 else 'json'
MAP={'json':b'J','msgpack':b'M','cbor':b'C','protobuf':b'P'}
if __name__=='__main__':
    payload=encode(FMT)
    print(f'Отправка в формате {FMT}, размер: {len(payload)} байт')
    with socket.create_connection((HOST,PORT),timeout=5) as client:
        client.sendall(MAP[FMT]+len(payload).to_bytes(4,'big')+payload)
    print('Отправлено.')
