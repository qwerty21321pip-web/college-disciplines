import json,timeit,statistics
from pathlib import Path
from formats import encode,decode
from data import PROFILE
if __name__=='__main__':
    Path('received').mkdir(exist_ok=True);report=[]
    print('Формат | Размер, байт | Запись, мкс | Чтение, мкс | Данные совпали')
    for fmt in ('json','xml','yaml','msgpack','cbor','protobuf'):
        b=encode(fmt);assert decode(fmt,b)==PROFILE
        enc=statistics.median(timeit.repeat(lambda:encode(fmt),number=1000,repeat=5))*1000
        dec=statistics.median(timeit.repeat(lambda:decode(fmt,b),number=1000,repeat=5))*1000
        row=dict(format=fmt,wire_size_bytes=len(b),encode_us=round(enc,3),decode_us=round(dec,3),roundtrip=True)
        report.append(row);print(f'{fmt} | {len(b)} | {enc:.3f} | {dec:.3f} | да')
    Path('received/report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
